"""
scorer.py
Core matching engine: compares a job description against one or more
resumes and produces an interpretable, weighted match score per
candidate, then ranks all candidates.

Scoring breakdown (weights sum to 100):
    - Skill match          : 45%   (overlap between JD-required skills and candidate skills)
    - Semantic/TF-IDF match : 30%   (overall textual/contextual similarity, via cosine similarity)
    - Experience match     : 15%   (candidate years vs required years)
    - Education match      : 10%   (candidate's highest degree vs required degree level)
"""

import re
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from nlp_processor import ResumeAnalyzer
from skills_database import DEGREE_RANK

WEIGHTS = {
    "skills": 0.45,
    "semantic": 0.30,
    "experience": 0.15,
    "education": 0.10,
}


class MatchingEngine:
    def __init__(self, jd_text: str):
        self.jd_text = jd_text
        self.jd_analyzer = ResumeAnalyzer(jd_text)
        self.jd_info = self.jd_analyzer.extract_all()
        self.jd_required_years = self._extract_required_years(jd_text)
        self.jd_required_degree_rank = self.jd_info["highest_degree_rank"]

    @staticmethod
    def _extract_required_years(jd_text: str):
        """Look for phrases like 'minimum 3 years', '3+ years' in the JD."""
        matches = re.findall(
            r"(\d+(?:\.\d+)?)\+?\s*(?:years|yrs)", jd_text, re.IGNORECASE
        )
        years = [float(m) for m in matches]
        return max(years) if years else 0.0

    # ---------- Individual sub-scores ----------
    def _skill_score(self, candidate_skills):
        jd_skills = set(self.jd_info["skills"])
        cand_skills = set(candidate_skills)
        if not jd_skills:
            return 1.0, [], []  # no explicit skills in JD -> don't penalize
        matched = sorted(jd_skills & cand_skills)
        missing = sorted(jd_skills - cand_skills)
        score = len(matched) / len(jd_skills)
        return score, matched, missing

    def _semantic_score(self, resume_text):
        corpus = [self.jd_text, resume_text]
        try:
            vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
            tfidf_matrix = vectorizer.fit_transform(corpus)
            sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            return float(sim)
        except ValueError:
            return 0.0

    def _experience_score(self, candidate_years):
        if self.jd_required_years <= 0:
            return 1.0  # JD doesn't specify -> full marks
        if candidate_years >= self.jd_required_years:
            return 1.0
        return round(candidate_years / self.jd_required_years, 3)

    def _education_score(self, candidate_rank):
        if self.jd_required_degree_rank <= 0:
            return 1.0  # JD doesn't specify a degree -> full marks
        if candidate_rank >= self.jd_required_degree_rank:
            return 1.0
        if candidate_rank <= 0:
            return 0.0
        return round(candidate_rank / self.jd_required_degree_rank, 3)

    # ---------- Public API ----------
    def score_resume(self, resume_text: str):
        analyzer = ResumeAnalyzer(resume_text)
        info = analyzer.extract_all()

        skill_score, matched_skills, missing_skills = self._skill_score(info["skills"])
        semantic_score = self._semantic_score(resume_text)
        exp_score = self._experience_score(info["experience_years"])
        edu_score = self._education_score(info["highest_degree_rank"])

        final_score = (
            skill_score * WEIGHTS["skills"]
            + semantic_score * WEIGHTS["semantic"]
            + exp_score * WEIGHTS["experience"]
            + edu_score * WEIGHTS["education"]
        ) * 100

        return {
            "name": info["name"],
            "email": info["email"],
            "phone": info["phone"],
            "final_score": round(final_score, 2),
            "skill_score": round(skill_score * 100, 1),
            "semantic_score": round(semantic_score * 100, 1),
            "experience_score": round(exp_score * 100, 1),
            "education_score": round(edu_score * 100, 1),
            "candidate_experience_years": info["experience_years"],
            "required_experience_years": self.jd_required_years,
            "candidate_education": ", ".join(info["education"]) if info["education"] else "Not specified",
            "matched_skills": matched_skills,
            "missing_skills": missing_skills,
            "all_candidate_skills": info["skills"],
        }

    def rank_candidates(self, resumes: dict):
        """
        resumes: dict of {display_filename: resume_text}
        Returns a pandas DataFrame sorted by final_score descending,
        plus the list of raw result dicts (for detailed UI display).
        """
        results = []
        for fname, text in resumes.items():
            result = self.score_resume(text)
            result["source_file"] = fname
            results.append(result)

        results.sort(key=lambda r: r["final_score"], reverse=True)
        for i, r in enumerate(results, start=1):
            r["rank"] = i

        df = pd.DataFrame([
            {
                "Rank": r["rank"],
                "Candidate": r["name"],
                "Source File": r["source_file"],
                "Overall Score (%)": r["final_score"],
                "Skill Match (%)": r["skill_score"],
                "Semantic Match (%)": r["semantic_score"],
                "Experience Match (%)": r["experience_score"],
                "Education Match (%)": r["education_score"],
                "Experience (yrs)": r["candidate_experience_years"],
                "Email": r["email"],
            }
            for r in results
        ])
        return df, results

    def jd_summary(self):
        return {
            "required_skills": self.jd_info["skills"],
            "required_experience_years": self.jd_required_years,
            "required_education": self.jd_info["education"],
        }
