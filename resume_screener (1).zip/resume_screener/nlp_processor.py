"""
nlp_processor.py
Extracts structured information (skills, education, work experience,
contact details) out of raw resume / job-description text using
regex + keyword-matching NLP techniques (no external model downloads
required, so it runs fully offline/self-contained).
"""

import re
from skills_database import ALL_SKILLS, SYNONYMS, DEGREE_KEYWORDS, DEGREE_RANK, normalize_skill

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(r"(\+?\d{1,3}[-.\s]?)?\(?\d{3,5}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}")
YEARS_EXP_RE = re.compile(
    r"(\d+(?:\.\d+)?)\+?\s*(?:years|yrs|year)\s*(?:of)?\s*(?:experience|exp)?",
    re.IGNORECASE
)
DATE_RANGE_RE = re.compile(
    r"(20\d{2}|19\d{2})\s*(?:-|to|–|—)\s*(20\d{2}|present|current|now)",
    re.IGNORECASE
)


class ResumeAnalyzer:
    """Extracts structured candidate/JD information from raw text."""

    def __init__(self, text: str):
        self.raw_text = text or ""
        self.text = self.raw_text.lower()

    # ---------- Contact info ----------
    def extract_email(self):
        match = EMAIL_RE.search(self.raw_text)
        return match.group(0) if match else None

    def extract_phone(self):
        match = PHONE_RE.search(self.raw_text)
        return match.group(0).strip() if match else None

    def extract_name(self):
        """
        Heuristic: the candidate's name is usually the first non-empty line
        that isn't an email/phone and looks like a short title-case string.
        """
        for line in self.raw_text.splitlines():
            line = line.strip()
            if not line:
                continue
            if EMAIL_RE.search(line) or PHONE_RE.search(line):
                continue
            words = line.split()
            if 1 <= len(words) <= 4 and all(w.replace(".", "").isalpha() for w in words):
                return line.title()
            break
        return "Unknown Candidate"

    # ---------- Skills ----------
    def extract_skills(self):
        """
        Scan text for any known skill (multi-word phrases included) using
        word-boundary matching, then normalize aliases to canonical names.
        """
        found = set()
        for skill in ALL_SKILLS:
            pattern = r"(?<![a-zA-Z0-9+#.])" + re.escape(skill) + r"(?![a-zA-Z0-9+#])"
            if re.search(pattern, self.text):
                found.add(skill)
        for alias in SYNONYMS:
            pattern = r"(?<![a-zA-Z0-9+#.])" + re.escape(alias) + r"(?![a-zA-Z0-9+#])"
            if re.search(pattern, self.text):
                found.add(normalize_skill(alias))
        return sorted(found)

    # ---------- Education ----------
    def extract_education(self):
        found_degrees = []
        for kw in DEGREE_KEYWORDS:
            pattern = r"(?<![a-zA-Z])" + re.escape(kw.strip()) + r"(?![a-zA-Z])"
            if re.search(pattern, self.text):
                found_degrees.append(kw.strip())
        # dedupe while preserving highest-rank representation
        return sorted(set(found_degrees))

    def highest_degree_rank(self):
        degrees = self.extract_education()
        rank = 0
        best = None
        for d in degrees:
            key = d.replace(".", "").strip()
            for rank_key, r in DEGREE_RANK.items():
                if rank_key.replace(".", "").strip() in key or key in rank_key.replace(".", "").strip():
                    if r > rank:
                        rank = r
                        best = rank_key
        return rank, best

    # ---------- Experience ----------
    def extract_experience_years(self):
        """
        Try to find an explicit 'X years of experience' statement first.
        If not found, fall back to estimating from date ranges found in
        an employment history (e.g. 2019-2022, 2022-present).
        """
        explicit_matches = YEARS_EXP_RE.findall(self.text)
        explicit_years = [float(m) for m in explicit_matches if m]
        if explicit_years:
            return max(explicit_years)

        # Fallback: sum up date-range durations
        total_months = 0
        for start, end in DATE_RANGE_RE.findall(self.text):
            start_year = int(start)
            end_year = 2026 if end.lower() in ("present", "current", "now") else int(end)
            if end_year >= start_year:
                total_months += (end_year - start_year) * 12
        if total_months > 0:
            return round(total_months / 12, 1)
        return 0.0

    # ---------- Aggregate ----------
    def extract_all(self):
        rank, best_degree = self.highest_degree_rank()
        return {
            "name": self.extract_name(),
            "email": self.extract_email(),
            "phone": self.extract_phone(),
            "skills": self.extract_skills(),
            "education": self.extract_education(),
            "highest_degree_rank": rank,
            "highest_degree": best_degree,
            "experience_years": self.extract_experience_years(),
        }
