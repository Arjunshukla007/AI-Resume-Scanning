"""
test_demo.py
Command-line demonstration of the AI Resume Screening System.
Runs the full pipeline (parse -> extract -> score -> rank) on the
sample job description and sample resumes bundled in sample_data/,
and prints a clean ranked report to the console.

Run with:  python3 test_demo.py
"""

import os
import glob
from resume_parser import extract_text
from scorer import MatchingEngine

SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "sample_data")


def main():
    jd_path = os.path.join(SAMPLE_DIR, "job_description.txt")
    with open(jd_path, "r", encoding="utf-8") as f:
        jd_text = f.read()

    resume_paths = sorted(glob.glob(os.path.join(SAMPLE_DIR, "resume_*.txt")))

    resumes = {}
    for path in resume_paths:
        fname = os.path.basename(path)
        resumes[fname] = extract_text(path)

    engine = MatchingEngine(jd_text)

    print("=" * 90)
    print("AI RESUME SCREENING SYSTEM — DEMO RUN")
    print("=" * 90)

    jd_info = engine.jd_summary()
    print("\n--- JOB DESCRIPTION ANALYSIS ---")
    print(f"Required Skills Detected ({len(jd_info['required_skills'])}):")
    print("  " + ", ".join(jd_info["required_skills"]))
    print(f"Minimum Experience Required: {jd_info['required_experience_years']} years")
    print(f"Education Keywords Detected: {', '.join(jd_info['required_education']) or 'None specified'}")

    df, results = engine.rank_candidates(resumes)

    print("\n--- CANDIDATE RANKING ---")
    print(df.to_string(index=False))

    print("\n--- DETAILED BREAKDOWN PER CANDIDATE ---")
    for r in results:
        print("\n" + "-" * 90)
        print(f"Rank #{r['rank']}: {r['name']}  |  Overall Score: {r['final_score']}%")
        print(f"  Source file        : {r['source_file']}")
        print(f"  Email              : {r['email']}")
        print(f"  Experience         : {r['candidate_experience_years']} yrs "
              f"(required: {r['required_experience_years']} yrs) -> {r['experience_score']}% match")
        print(f"  Education          : {r['candidate_education']} -> {r['education_score']}% match")
        print(f"  Skill Match Score  : {r['skill_score']}%")
        print(f"  Semantic/Text Score: {r['semantic_score']}%")
        print(f"  Matched Skills ({len(r['matched_skills'])}): {', '.join(r['matched_skills']) or 'None'}")
        print(f"  Missing Skills ({len(r['missing_skills'])}): {', '.join(r['missing_skills']) or 'None'}")

    print("\n" + "=" * 90)
    print("Top recommended candidate(s) for further evaluation:")
    top_score = results[0]["final_score"]
    for r in results:
        if r["final_score"] >= top_score - 15:  # show close contenders too
            print(f"  -> {r['name']} ({r['final_score']}%)")
    print("=" * 90)


if __name__ == "__main__":
    main()
