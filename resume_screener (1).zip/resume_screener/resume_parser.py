"""
resume_parser.py
Handles extraction of raw text from resumes supplied as PDF, DOCX or TXT
files (or in-memory file-like objects, e.g. from a Streamlit uploader).
"""

import os
import io
import docx
import pdfplumber


def extract_text_from_pdf(file) -> str:
    """Extract text from a PDF given a path or a file-like object."""
    text_chunks = []
    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_chunks.append(page_text)
    return "\n".join(text_chunks)


def extract_text_from_docx(file) -> str:
    """Extract text from a DOCX given a path or a file-like object."""
    document = docx.Document(file)
    paragraphs = [p.text for p in document.paragraphs]
    # Also pull text out of tables (many resumes use table layouts)
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text:
                    paragraphs.append(cell.text)
    return "\n".join(paragraphs)


def extract_text_from_txt(file) -> str:
    """Extract text from a plain text file (path or file-like object)."""
    if isinstance(file, (str, os.PathLike)):
        with open(file, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    else:
        raw = file.read()
        if isinstance(raw, bytes):
            return raw.decode("utf-8", errors="ignore")
        return raw


def extract_text(file, filename: str = None) -> str:
    """
    Dispatch to the correct extractor based on file extension.
    `file` can be a path (str) or a file-like object (e.g. Streamlit's
    UploadedFile). If `file` is file-like, `filename` must be supplied
    so we know the extension.
    """
    if filename is None:
        filename = file if isinstance(file, str) else getattr(file, "name", "")

    ext = os.path.splitext(filename)[1].lower()

    try:
        if ext == ".pdf":
            return extract_text_from_pdf(file)
        elif ext == ".docx":
            return extract_text_from_docx(file)
        elif ext in (".txt", ".text"):
            return extract_text_from_txt(file)
        else:
            raise ValueError(f"Unsupported file type: {ext}")
    except Exception as e:
        raise RuntimeError(f"Failed to parse '{filename}': {e}")
