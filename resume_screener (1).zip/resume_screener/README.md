# 🧠 AI Resume Screening System

An AI/NLP-powered decision-support tool that automatically screens and ranks
resumes against a job description — built to reduce manual recruiter effort
and make initial candidate shortlisting faster and more consistent.

---

## ✨ Features

- Accepts a **Job Description** (pasted text, or `.pdf` / `.docx` / `.txt` file)
- Accepts **multiple resumes** at once (`.pdf`, `.docx`, `.txt`)
- Extracts structured information from every document:
  - Skills (100+ skill vocabulary across programming, ML/DS, cloud, databases, soft skills, etc.)
  - Education level / degree
  - Years of work experience
  - Name, email, phone
- Automatically detects the **requirements from the JD** (required skills, minimum experience, education level)
- Computes a **weighted match score (0–100%)** per candidate:
  | Component | Weight | What it measures |
  |---|---|---|
  | Skill Match | 45% | Overlap between JD-required skills and candidate skills |
  | Semantic/Contextual Match | 30% | TF-IDF cosine similarity between full JD & resume text |
  | Experience Match | 15% | Candidate years vs. required years |
  | Education Match | 10% | Candidate's highest degree vs. required degree level |
- **Ranks all candidates** from best to worst match
- Shows **matched vs. missing skills** per candidate so recruiters know exactly why someone scored the way they did
- Clean **Streamlit web interface** with score badges, progress bars, and a downloadable CSV report

---

## 📁 Project Structure

```
resume_screener/
├── app.py                  # Streamlit web interface (main entry point)
├── resume_parser.py        # PDF / DOCX / TXT text extraction
├── nlp_processor.py        # Skill / education / experience / contact extraction
├── scorer.py                # Matching engine — computes weighted scores & ranks candidates
├── skills_database.py      # Curated skills knowledge base + synonyms + degree keywords
├── test_demo.py            # CLI script to run the pipeline on sample data (no UI needed)
├── requirements.txt
├── sample_data/
│   ├── job_description.txt
│   ├── resume_1_ananya.txt   (strong match example)
│   ├── resume_2_rahul.txt    (moderate match example)
│   ├── resume_3_priya.txt    (mismatched/weak example)
│   └── resume_4_karan.txt    (strongest match example)
└── README.md
```

---

## 🚀 How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Launch the web app
```bash
streamlit run app.py
```
This opens the interface in your browser (usually `http://localhost:8501`).

- In the **sidebar**, paste or upload a job description
- Upload one or more candidate resumes
- Click **"🚀 Screen & Rank Candidates"**
- View the ranked table, per-candidate breakdown, matched/missing skills, and download results as CSV

### 3. (Optional) Try the CLI demo instead
If you just want to see it work quickly without a browser:
```bash
python3 test_demo.py
```
This runs the full pipeline on the bundled `sample_data/` files and prints a ranked report to the console.

---

## 🧩 How the Matching Works

1. **Text Extraction** — `resume_parser.py` pulls raw text out of PDF/DOCX/TXT files.
2. **Information Extraction** — `nlp_processor.py` scans the text with regex and a
   curated skills dictionary (`skills_database.py`) to pull out skills, education,
   experience (in years), and contact details. Synonym mapping (e.g. `js` → `javascript`,
   `ml` → `machine learning`) ensures skills are matched even when phrased differently.
3. **Requirement Detection** — the same extraction pipeline runs on the job description
   itself, so the system automatically knows what skills, experience level, and education
   the role requires — no manual tagging needed.
4. **Scoring** — `scorer.py` combines four sub-scores (skills, semantic similarity via
   TF-IDF + cosine similarity, experience, education) into one weighted final score.
5. **Ranking** — all candidates are sorted by final score, producing a shortlist ordered
   from most to least relevant.

This uses classic, transparent NLP/ML techniques (TF-IDF, cosine similarity, rule-based
entity extraction) rather than opaque black-box models — every score is explainable,
which matters for a tool recruiters will actually rely on and need to justify decisions from.

---

## 🔧 Extending the System

- **Add more skills**: edit `skills_database.py` — add entries to any category or the `SYNONYMS` dict.
- **Adjust scoring weights**: edit the `WEIGHTS` dict at the top of `scorer.py`.
- **Bulk-screen a folder**: modify `test_demo.py` to point at any directory of resumes.
- **Persist results**: the ranking output is a pandas DataFrame — easy to write to a database, Excel file, or ATS integration.

---

## ⚠️ Notes & Limitations

- This is a **decision-support tool**, not an automated hiring decision-maker — it's designed
  to help recruiters prioritize review effort, not replace human judgment.
- Extraction accuracy depends on resume formatting; heavily image-based or unusually
  formatted PDFs may extract text less reliably (standard for any text-based parser).
- Skill/experience detection is keyword and pattern-based for transparency and speed;
  it can be swapped for a transformer-based NER model if higher extraction accuracy is needed.
