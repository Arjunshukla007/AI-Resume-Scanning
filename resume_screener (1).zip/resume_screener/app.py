"""
app.py
Streamlit web interface for the AI Resume Screening System.

Run with:
    streamlit run app.py
"""

import io
import pandas as pd
import streamlit as st

from resume_parser import extract_text
from scorer import MatchingEngine

st.set_page_config(
    page_title="AI Resume Screening System",
    page_icon="🧠",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Styling
# ---------------------------------------------------------------------------
st.markdown("""
<style>
    .main-header {
        font-size: 2.1rem;
        font-weight: 700;
        color: #1f2d3d;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        color: #5a6b7d;
        font-size: 1rem;
        margin-bottom: 1.5rem;
    }
    .score-badge {
        display: inline-block;
        padding: 4px 14px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 1.1rem;
        color: white;
    }
    .rank-card {
        border: 1px solid #e5e9ee;
        border-radius: 10px;
        padding: 16px 20px;
        margin-bottom: 14px;
        background-color: #ffffff;
    }
    .skill-chip {
        display: inline-block;
        background-color: #eaf7ee;
        color: #1c7c3f;
        border-radius: 12px;
        padding: 2px 10px;
        margin: 2px;
        font-size: 0.82rem;
    }
    .missing-chip {
        display: inline-block;
        background-color: #fdeceb;
        color: #b3261e;
        border-radius: 12px;
        padding: 2px 10px;
        margin: 2px;
        font-size: 0.82rem;
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-header">🧠 AI Resume Screening System</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="sub-header">Upload a job description and multiple resumes — '
    'the system extracts skills, education & experience, then ranks candidates '
    'by relevance using NLP-based matching.</div>',
    unsafe_allow_html=True
)


def score_color(score):
    if score >= 70:
        return "#1c7c3f"   # green
    elif score >= 45:
        return "#c98a00"   # amber
    else:
        return "#b3261e"   # red


# ---------------------------------------------------------------------------
# Sidebar — Job Description input
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("1️⃣ Job Description")
    jd_input_mode = st.radio("Provide JD via:", ["Paste text", "Upload file"], horizontal=True)

    jd_text = ""
    if jd_input_mode == "Paste text":
        jd_text = st.text_area("Paste the job description here:", height=280,
                                placeholder="e.g. We are looking for a Data Scientist with 3+ years "
                                             "of experience in Python, Machine Learning, SQL...")
    else:
        jd_file = st.file_uploader("Upload JD (.pdf, .docx, .txt)", type=["pdf", "docx", "txt"])
        if jd_file is not None:
            jd_text = extract_text(jd_file, filename=jd_file.name)
            with st.expander("Preview extracted JD text"):
                st.text(jd_text[:2000])

    st.markdown("---")
    st.header("2️⃣ Candidate Resumes")
    resume_files = st.file_uploader(
        "Upload one or more resumes (.pdf, .docx, .txt)",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
    )

    st.markdown("---")
    run_button = st.button("🚀 Screen & Rank Candidates", use_container_width=True, type="primary")

    st.markdown("---")
    st.caption(
        "**Scoring weights** — Skill Match 45% · Semantic/Contextual Match 30% · "
        "Experience Match 15% · Education Match 10%"
    )

# ---------------------------------------------------------------------------
# Main panel
# ---------------------------------------------------------------------------
if run_button:
    if not jd_text or not jd_text.strip():
        st.error("Please provide a job description before running the screening.")
        st.stop()
    if not resume_files:
        st.error("Please upload at least one resume.")
        st.stop()

    with st.spinner("Parsing resumes and computing match scores..."):
        resumes = {}
        parse_errors = []
        for f in resume_files:
            try:
                text = extract_text(f, filename=f.name)
                if text.strip():
                    resumes[f.name] = text
                else:
                    parse_errors.append(f.name)
            except Exception as e:
                parse_errors.append(f"{f.name} ({e})")

        if parse_errors:
            st.warning(f"Could not extract text from: {', '.join(parse_errors)}")

        if not resumes:
            st.error("No resumes could be parsed successfully.")
            st.stop()

        engine = MatchingEngine(jd_text)
        jd_summary = engine.jd_summary()
        df, results = engine.rank_candidates(resumes)

    # --- JD Analysis summary ---
    st.subheader("📋 Job Description — Extracted Requirements")
    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Skills Identified", len(jd_summary["required_skills"]))
    with c2:
        st.metric("Min. Experience Required", f"{jd_summary['required_experience_years']} yrs")
    with c3:
        st.metric("Education Level Detected", jd_summary["required_education"][0].upper()
                   if jd_summary["required_education"] else "Not specified")

    with st.expander("View all required skills detected from the JD"):
        chips = "".join([f'<span class="skill-chip">{s}</span>' for s in jd_summary["required_skills"]])
        st.markdown(chips if chips else "_No specific skills detected — scoring will rely more on semantic match._",
                    unsafe_allow_html=True)

    st.markdown("---")

    # --- Ranking table ---
    st.subheader(f"🏆 Candidate Ranking ({len(results)} resumes screened)")
    st.dataframe(
        df.style.background_gradient(subset=["Overall Score (%)"], cmap="RdYlGn", vmin=0, vmax=100),
        use_container_width=True,
        hide_index=True,
    )

    csv_bytes = df.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download Ranking as CSV", data=csv_bytes,
                        file_name="resume_screening_results.csv", mime="text/csv")

    st.markdown("---")

    # --- Detailed per-candidate cards ---
    st.subheader("🔍 Detailed Candidate Breakdown")
    for r in results:
        color = score_color(r["final_score"])
        with st.container():
            st.markdown('<div class="rank-card">', unsafe_allow_html=True)
            top_col1, top_col2 = st.columns([4, 1])
            with top_col1:
                st.markdown(f"**#{r['rank']} — {r['name']}**  \n"
                            f"📧 {r['email'] or 'N/A'}   |   📱 {r['phone'] or 'N/A'}   |   📄 `{r['source_file']}`")
            with top_col2:
                st.markdown(
                    f'<span class="score-badge" style="background-color:{color};">{r["final_score"]}%</span>',
                    unsafe_allow_html=True
                )

            b1, b2, b3, b4 = st.columns(4)
            b1.progress(int(r["skill_score"]), text=f"Skills {r['skill_score']}%")
            b2.progress(int(r["semantic_score"]), text=f"Semantic {r['semantic_score']}%")
            b3.progress(int(r["experience_score"]), text=f"Experience {r['experience_score']}%")
            b4.progress(int(r["education_score"]), text=f"Education {r['education_score']}%")

            st.caption(
                f"Experience: **{r['candidate_experience_years']} yrs** "
                f"(required: {r['required_experience_years']} yrs)  |  "
                f"Education: **{r['candidate_education']}**"
            )

            st.markdown("**✅ Matched Skills**")
            if r["matched_skills"]:
                st.markdown("".join([f'<span class="skill-chip">{s}</span>' for s in r["matched_skills"]]),
                            unsafe_allow_html=True)
            else:
                st.caption("None detected")

            st.markdown("**❌ Missing Skills (present in JD, not found in resume)**")
            if r["missing_skills"]:
                st.markdown("".join([f'<span class="missing-chip">{s}</span>' for s in r["missing_skills"]]),
                            unsafe_allow_html=True)
            else:
                st.caption("None — full skill coverage")

            st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    top_candidate = results[0]
    st.success(
        f"✅ **Recommended for next round:** {top_candidate['name']} "
        f"({top_candidate['final_score']}% match). "
        f"Review the full ranking table above for other strong candidates."
    )

else:
    st.info(
        "👈 Provide a job description and upload resumes in the sidebar, then click "
        "**'Screen & Rank Candidates'** to get started.\n\n"
        "**Try it quickly:** load a sample JD and resumes from the `sample_data/` folder "
        "bundled with this project."
    )
    st.markdown("""
    ### How it works
    1. **Extraction** — Resume text (PDF/DOCX/TXT) is parsed and structured info
       (skills, education, experience, contact details) is pulled out using regex + a
       curated skills knowledge base.
    2. **Requirement detection** — The same pipeline runs on the job description to
       identify required skills, minimum experience, and education level.
    3. **Matching** — Each resume is compared against the JD using:
       - **Skill overlap** (45%)
       - **TF-IDF cosine similarity** for overall contextual relevance (30%)
       - **Experience match** (15%)
       - **Education match** (10%)
    4. **Ranking** — Candidates are sorted by overall match score, with a full
       breakdown and matched/missing skills shown for each.
    """)
