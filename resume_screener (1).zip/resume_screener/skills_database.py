"""
skills_database.py
Central repository of known skills (categorized) and synonym/alias mapping
used by the NLP processor to detect skills inside free-text resumes and
job descriptions.
"""

SKILLS_DB = {
    "programming_languages": [
        "python", "java", "c++", "c#", "javascript", "typescript", "go", "golang",
        "rust", "ruby", "php", "swift", "kotlin", "scala", "r", "matlab", "perl",
        "c", "dart", "sql", "bash", "shell scripting", "objective-c"
    ],
    "web_frameworks": [
        "django", "flask", "fastapi", "react", "reactjs", "angular", "vue", "vuejs",
        "node.js", "nodejs", "express.js", "express", "spring", "spring boot",
        "asp.net", ".net", "next.js", "nextjs", "svelte", "jquery", "bootstrap",
        "tailwind", "tailwindcss", "html", "html5", "css", "css3", "rest api",
        "restful api", "graphql", "webpack"
    ],
    "data_science_ml": [
        "machine learning", "deep learning", "natural language processing", "nlp",
        "computer vision", "artificial intelligence", "ai", "data science",
        "data analysis", "data analytics", "predictive modeling",
        "neural networks", "reinforcement learning", "statistics",
        "scikit-learn", "sklearn", "tensorflow", "pytorch", "keras", "pandas",
        "numpy", "matplotlib", "seaborn", "opencv", "nltk", "spacy",
        "hugging face", "transformers", "llm", "large language models",
        "generative ai", "genai", "mlops", "feature engineering",
        "data visualization", "regression", "classification", "clustering",
        "time series analysis", "a/b testing", "recommendation systems"
    ],
    "databases": [
        "mysql", "postgresql", "postgres", "mongodb", "sqlite", "oracle",
        "sql server", "redis", "cassandra", "dynamodb", "elasticsearch",
        "firebase", "mariadb", "nosql", "database design", "database management"
    ],
    "cloud_devops": [
        "aws", "amazon web services", "azure", "gcp", "google cloud",
        "docker", "kubernetes", "k8s", "jenkins", "ci/cd", "terraform",
        "ansible", "linux", "git", "github", "gitlab", "bitbucket",
        "devops", "microservices", "serverless", "lambda", "ec2", "s3",
        "cloud computing", "openshift", "nginx", "apache"
    ],
    "tools_platforms": [
        "excel", "power bi", "tableau", "jira", "confluence", "figma",
        "postman", "vs code", "visual studio", "eclipse", "intellij",
        "android studio", "unity", "salesforce", "sap", "servicenow"
    ],
    "soft_skills": [
        "communication", "leadership", "teamwork", "problem solving",
        "critical thinking", "time management", "project management",
        "collaboration", "adaptability", "creativity", "presentation skills",
        "stakeholder management", "mentoring", "negotiation",
        "decision making", "analytical skills", "attention to detail"
    ],
    "methodologies": [
        "agile", "scrum", "kanban", "waterfall", "lean", "six sigma",
        "test driven development", "tdd", "object oriented programming", "oop",
        "design patterns", "system design", "software development life cycle",
        "sdlc"
    ],
    "mobile": [
        "android", "ios", "react native", "flutter", "xamarin", "mobile development"
    ]
}

# Flatten into a single set for quick lookup
ALL_SKILLS = set()
for _category, _skills in SKILLS_DB.items():
    for _s in _skills:
        ALL_SKILLS.add(_s.lower())

# Aliases / synonyms -> canonical skill name (helps match "js" == "javascript" etc.)
SYNONYMS = {
    "js": "javascript",
    "ts": "typescript",
    "ml": "machine learning",
    "dl": "deep learning",
    "cv": "computer vision",
    "nlp": "natural language processing",
    "ai": "artificial intelligence",
    "k8s": "kubernetes",
    "aws cloud": "aws",
    "amazon web services": "aws",
    "google cloud platform": "gcp",
    "postgres": "postgresql",
    "reactjs": "react",
    "vuejs": "vue",
    "nodejs": "node.js",
    "expressjs": "express.js",
    "sklearn": "scikit-learn",
    "oop": "object oriented programming",
    "tdd": "test driven development",
    "sdlc": "software development life cycle",
    "genai": "generative ai",
    "power-bi": "power bi",
    "golang": "go",
}

DEGREE_KEYWORDS = [
    "phd", "ph.d", "doctorate",
    "m.tech", "mtech", "master of technology",
    "m.e", "me ", "master of engineering",
    "mba", "master of business administration",
    "mca", "master of computer applications",
    "m.sc", "msc", "master of science",
    "m.a", "ma ", "master of arts",
    "b.tech", "btech", "bachelor of technology",
    "b.e", "be ", "bachelor of engineering",
    "bca", "bachelor of computer applications",
    "b.sc", "bsc", "bachelor of science",
    "b.a", "ba ", "bachelor of arts",
    "bachelor", "master", "diploma", "associate degree"
]

DEGREE_RANK = {
    "phd": 5, "doctorate": 5,
    "master": 4, "m.tech": 4, "mtech": 4, "m.e": 4, "mba": 4, "mca": 4,
    "m.sc": 4, "msc": 4, "m.a": 4,
    "bachelor": 3, "b.tech": 3, "btech": 3, "b.e": 3, "bca": 3, "b.sc": 3,
    "bsc": 3, "b.a": 3,
    "diploma": 2, "associate degree": 2,
}


def normalize_skill(skill: str) -> str:
    """Map an alias to its canonical skill name if one exists."""
    skill = skill.lower().strip()
    return SYNONYMS.get(skill, skill)
